package com.example.news3;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NewsArticleAdapter extends ArrayAdapter<NewsArticle> {

    private static final String DATE_SEPARATOR = "T";

    private static final String LOG_TAG = NewsArticleAdapter.class.getName();

    public NewsArticleAdapter(Activity context, List<NewsArticle> articles) {
        super(context, 0, articles);
    }

    @androidx.annotation.NonNull
    @Override
    public View getView(int position, @androidx.annotation.Nullable View convertView, @androidx.annotation.NonNull ViewGroup parent) {
        View listItemView = convertView;

        if (listItemView == null) {

            listItemView = LayoutInflater.from(getContext()).inflate(

                    R.layout.news_list_item, parent, false);
        }
        NewsArticle currentArticle = getItem(position);

        TextView titleView = listItemView.findViewById(com.example.news3.R.id.title);
        titleView.setText(currentArticle.getTitle());

        TextView authorView = listItemView.findViewById(com.example.news3.R.id.author);
        authorView.setText(currentArticle.getAuthor());

        TextView sectionView = listItemView.findViewById(com.example.news3.R.id.section);
        sectionView.setText(currentArticle.getSection());

        String originalDate = currentArticle.getDate();

        String[] parts = originalDate.split(DATE_SEPARATOR);

        String date = parts[0];
        TextView dateView = listItemView.findViewById(com.example.news3.R.id.date);

        dateView.setText(date);
        return listItemView;
    }
}